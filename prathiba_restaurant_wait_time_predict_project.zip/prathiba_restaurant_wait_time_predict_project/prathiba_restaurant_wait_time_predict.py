# ============================================================
# RESTAURANT WAIT TIME PREDICTION
# SUPERVISED LEARNING – RANDOM FOREST
# ============================================================

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import joblib
import warnings
warnings.filterwarnings("ignore")

from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.metrics import r2_score, mean_absolute_error, mean_squared_error
from sklearn.ensemble import RandomForestRegressor

def generate_dataset():
    np.random.seed(42)
    rows = 1500

    df = pd.DataFrame({
        "day_of_week": np.random.choice(
            ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"], rows),
        "time_slot": np.random.choice(["Breakfast","Lunch","Dinner"], rows),
        "customers_waiting": np.random.randint(0, 80, rows),
        "tables_available": np.random.randint(0, 30, rows),
        "staff_on_duty": np.random.randint(3, 20, rows),
        "avg_prep_time": np.random.randint(5, 40, rows),
        "is_weekend": np.random.choice([0,1], rows)
    })

    # Base waiting time formula
    df["wait_time"] = (
        5
        + df["customers_waiting"] * 0.65
        - df["tables_available"] * 1.4
        - df["staff_on_duty"] * 0.8
        + df["avg_prep_time"] * 0.75
        + df["is_weekend"] * 10
        + np.random.normal(0, 4, rows)
    )

    # -------------------------------
    # 1️⃣ Introduce MISSING VALUES (3–5%)
    # -------------------------------
    for col in ["customers_waiting", "tables_available", "staff_on_duty", "avg_prep_time"]:
        df.loc[df.sample(frac=0.04).index, col] = np.nan

    # -------------------------------
    # 2️⃣ Introduce DUPLICATE ROWS (~2%)
    # -------------------------------
    duplicate_rows = df.sample(frac=0.02, random_state=42)
    df = pd.concat([df, duplicate_rows], ignore_index=True)

    # -------------------------------
    # 3️⃣ Introduce OUTLIERS (Extreme Scenarios)
    # -------------------------------
    outlier_indices = df.sample(frac=0.02, random_state=1).index
    df.loc[outlier_indices, "customers_waiting"] = np.random.randint(120, 200)
    df.loc[outlier_indices, "wait_time"] = np.random.randint(120, 180)

    # Ensure no negative waiting time
    df["wait_time"] = df["wait_time"].clip(0)

    df.to_csv("prathiba_restaurant_wait_time_dataset.csv", index=False)
    print("✅ Realistic dataset generated with noise, nulls, duplicates & outliers")

    return df


# ============================================================
# 2. DATA INSPECTION
# ============================================================
#“Initial exploratory inspection using head(), info(), and describe() was performed to
# understand data structure, detect missing values, and guide preprocessing decisions.”

def initial_data_inspection(df):
    print("\n🔍 INITIAL DATA INSPECTION")

    print("\n📌 First 5 rows:")
    print(df.head())

    print("\n📌 Dataset shape:")
    print(df.shape)

    print("\n📌 Data types & null info:")
    print(df.info())

    print("\n📌 Statistical summary (numeric):")
    print(df.describe())

    print("\n📌 Categorical summary:")
    print(df.describe(include="object"))

# ============================================================
# 3. DATA PREPROCESSING
# ============================================================

def handle_missing_values(df):
    print("\n🔍 STEP 1: Missing Value Handling")

    print("\n📌 Missing values BEFORE handling:")
    print(df.isnull().sum())

    num_cols = df.select_dtypes(include=np.number).columns
    cat_cols = df.select_dtypes(include="object").columns

    for col in num_cols:
        df[col].fillna(df[col].median(), inplace=True)

    for col in cat_cols:
        df[col].fillna(df[col].mode()[0], inplace=True)

    print("\n✅ Missing values AFTER handling:")
    print(df.isnull().sum())

    return df


def remove_duplicates(df):
    print("\n🔁 STEP 2: Duplicate Record Removal")

    before = df.shape[0]
    duplicate_count = df.duplicated().sum()

    print(f"📌 Duplicate rows found: {duplicate_count}")

    df = df.drop_duplicates()
    after = df.shape[0]

    print(f"✅ Rows removed: {before - after}")
    print(f"📊 Dataset size AFTER deduplication: {after}")

    return df


def handle_outliers(df):
    print("\n📉 STEP 3: Outlier Treatment using IQR Method")

    num_cols = [
        "customers_waiting",
        "tables_available",
        "staff_on_duty",
        "avg_prep_time",
        "wait_time"
    ]

    for col in num_cols:
        Q1 = df[col].quantile(0.25)
        Q3 = df[col].quantile(0.75)
        IQR = Q3 - Q1

        lower = Q1 - 1.5 * IQR
        upper = Q3 + 1.5 * IQR

        outliers_before = ((df[col] < lower) | (df[col] > upper)).sum()

        df[col] = df[col].clip(lower, upper)

        outliers_after = ((df[col] < lower) | (df[col] > upper)).sum()

        print(f"🔹 {col}")
        print(f"   Outliers before: {outliers_before}")
        print(f"   Outliers after : {outliers_after}")

    return df

def preprocess_data(df):
    print("\n🧹 STARTING DATA PREPROCESSING PIPELINE")
    print(f"📊 Initial dataset shape: {df.shape}")

    df = handle_missing_values(df)
    df = remove_duplicates(df)
    df = handle_outliers(df)

    print(f"\n✅ Final dataset shape after preprocessing: {df.shape}")
    print("🧹 Data preprocessing completed successfully")

    return df
# ============================================================
# 4. FEATURE ENGINEERING
# ============================================================

def feature_engineering(df):
    df = df.copy()

    df["is_peak_hour"] = df["time_slot"].map({
        "Breakfast": 0,
        "Lunch": 1,
        "Dinner": 1
    })

    df["load_per_staff"] = df["customers_waiting"] / (df["staff_on_duty"] + 1)

    return df

# ============================================================
# 5. EXPLORATORY DATA ANALYSIS
# ============================================================

def perform_eda(df):
    print("📊 Performing Exploratory Data Analysis")

    # Target distribution
    plt.figure(figsize=(8,5))
    sns.histplot(df["wait_time"], bins=25, kde=True)
    plt.title("Distribution of Restaurant Waiting Time")
    plt.xlabel("Waiting Time (minutes)")
    plt.ylabel("Frequency")
    plt.show()

    # Customer load vs avg wait time
    cust_bins = pd.cut(df["customers_waiting"], bins=[0,10,25,50,80])
    mean_wait = df.groupby(cust_bins, observed=True)["wait_time"].mean()

    plt.figure(figsize=(8,5))
    mean_wait.plot(marker="o")
    plt.title("Average Waiting Time vs Customer Load")
    plt.xlabel("Customer Load Groups")
    plt.ylabel("Average Waiting Time (minutes)")
    plt.grid(True)
    plt.show()

    # Peak vs Non-Peak (Histogram)
    fig, axes = plt.subplots(1, 2, figsize=(12,5), sharey=True)

    sns.histplot(df[df["is_peak_hour"]==0]["wait_time"], bins=30, kde=True, ax=axes[0])
    axes[0].set_title("Non-Peak Hours")

    sns.histplot(df[df["is_peak_hour"]==1]["wait_time"], bins=30, kde=True, ax=axes[1])
    axes[1].set_title("Peak Hours")

    plt.suptitle("Waiting Time Distribution by Time Period")
    plt.show()

    # Load per staff vs wait time
    plt.figure(figsize=(8,5))
    sns.scatterplot(x=df["load_per_staff"], y=df["wait_time"], alpha=0.6)
    plt.title("Staff Load vs Waiting Time")
    plt.xlabel("Load per Staff")
    plt.ylabel("Waiting Time (minutes)")
    plt.show()

    # Correlation heatmap
    corr_features = [
        "wait_time",
        "customers_waiting",
        "tables_available",
        "staff_on_duty",
        "avg_prep_time",
        "load_per_staff",
        "is_peak_hour"
    ]

    plt.figure(figsize=(8,6))
    sns.heatmap(df[corr_features].corr(), annot=True, cmap="coolwarm", fmt=".2f")
    plt.title("Correlation Matrix of Key Features")
    plt.show()

# ============================================================
# 6. MODEL TRAINING + HYPERPARAMETER TUNING
# ============================================================

def train_model(df):
    print("⚙️ Training Random Forest Model")

    X = df.drop("wait_time", axis=1)
    y = df["wait_time"]

    cat_cols = ["day_of_week", "time_slot"]
    num_cols = [c for c in X.columns if c not in cat_cols]

    preprocessor = ColumnTransformer([
        ("num", StandardScaler(), num_cols),
        ("cat", OneHotEncoder(handle_unknown="ignore"), cat_cols)
    ])

    pipeline = Pipeline([
        ("prep", preprocessor),
        ("model", RandomForestRegressor(random_state=42))
    ])

    param_grid = {
        "model__n_estimators": [150, 250],
        "model__max_depth": [10, 15, None],
        "model__min_samples_split": [2, 5],
        "model__min_samples_leaf": [1, 2]
    }

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )

    grid = GridSearchCV(
        pipeline,
        param_grid,
        cv=5,
        scoring="r2",
        n_jobs=-1
    )

    grid.fit(X_train, y_train)

    best_model = grid.best_estimator_
    y_pred = best_model.predict(X_test)

    print("\n✅ Model Performance")
    print("R2   :", r2_score(y_test, y_pred))
    print("MAE  :", mean_absolute_error(y_test, y_pred))
    print("RMSE :", np.sqrt(mean_squared_error(y_test, y_pred)))

    joblib.dump(best_model, "best_model.pkl")
    print("💾 Model saved as best_model.pkl")

    plot_feature_importance(best_model)

# ============================================================
# 7. FEATURE IMPORTANCE VISUALIZATION
# ============================================================

def plot_feature_importance(trained_pipeline):
    preprocessor = trained_pipeline.named_steps["prep"]
    model = trained_pipeline.named_steps["model"]

    feature_names = preprocessor.get_feature_names_out()
    importances = model.feature_importances_

    fi_df = pd.DataFrame({
        "Feature": feature_names,
        "Importance": importances
    }).sort_values(by="Importance", ascending=False)

    plt.figure(figsize=(10,6))
    plt.barh(fi_df["Feature"], fi_df["Importance"])
    plt.gca().invert_yaxis()
    plt.title("Feature Importance – Random Forest")
    plt.xlabel("Importance Score")
    plt.tight_layout()
    plt.show()

# ============================================================
# MAIN EXECUTION BLOCK
# ============================================================

if __name__ == "__main__":

    print("🚀 Starting Restaurant Wait Time Prediction Pipeline")

    df = generate_dataset()
    initial_data_inspection(df)

    df = preprocess_data(df)

    df = feature_engineering(df)

    perform_eda(df)

    train_model(df)

    print("✅ Pipeline execution completed successfully")
