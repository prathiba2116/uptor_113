from flask import Flask, request, jsonify
import joblib
import pandas as pd

app = Flask(__name__)

# Load trained model
model = joblib.load("best_model.pkl")

@app.route("/")
def home():
    return "Flask API is running"

@app.route("/predict", methods=["POST"])
def predict():
    data = request.get_json()

    # Convert to DataFrame
    df = pd.DataFrame([data])

    # Feature engineering (MUST match training)
    df["load_per_staff"] = df["customers_waiting"] / (df["staff_on_duty"] + 1)
    df["is_peak_hour"] = df["time_slot"].map({
        "Breakfast": 0,
        "Lunch": 1,
        "Dinner": 1
    })

    prediction = model.predict(df)[0]

    return jsonify({
        "predicted_wait_time": round(float(prediction), 2)
    })

if __name__ == "__main__":
    app.run(debug=True)
