import streamlit as st
import requests
import time

# =====================================================
# PAGE CONFIG
# =====================================================
st.set_page_config(
    page_title="Restaurant Wait Time Prediction",
    page_icon="🍽️",
    layout="wide"
)

# =====================================================
# THEME COLORS (GREEN / FRESH)
# =====================================================
APP_BG = "linear-gradient(180deg, #ecfdf5, #f0fdf4)"
CARD_BG = "#ffffff"
ACCENT = "#10b981"   # emerald green
TEXT = "#064e3b"
BORDER = "#a7f3d0"

# =====================================================
# GLOBAL CSS (FINAL POLISHED UI)
# =====================================================
st.markdown(f"""
<style>
/* App Background */
.stApp {{
    background: {APP_BG};
    color: {TEXT};
}}

.block-container {{
    max-width: 1200px;
    padding-top: 2rem;
}}

/* ================= HEADER ================= */
.app-header {{
    display: flex;
    align-items: center;
    gap: 20px;
    background: linear-gradient(90deg, #10b981, #34d399);
    padding: 26px 30px;
    border-radius: 16px;
    color: white;
    margin-bottom: 30px;
    animation: headerFade 0.8s ease-out;
}}

@keyframes headerFade {{
    from {{
        opacity: 0;
        transform: translateY(-12px);
    }}
    to {{
        opacity: 1;
        transform: translateY(0);
    }}
}}

/* Logo */
.logo-box {{
    width: 60px;
    height: 60px;
    background-color: rgba(255,255,255,0.25);
    border-radius: 14px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 28px;
    box-shadow: 0 4px 12px rgba(16,185,129,0.35);
    transition: transform 0.3s ease;
}}

.logo-box:hover {{
    transform: rotate(-2deg) scale(1.05);
}}

.header-text h1 {{
    font-size: 2.1rem;
    margin: 0;
}}

.header-text p {{
    margin: 0;
    font-size: 1rem;
    opacity: 0.95;
}}

/* ================= CARDS ================= */
.card {{
    background-color: {CARD_BG};
    border-radius: 14px;
    padding: 22px;
    margin-bottom: 22px;
    border: 1px solid {BORDER};
    box-shadow: 0 6px 16px rgba(0,0,0,0.08);
}}

.card-title {{
    font-size: 1.15rem;
    font-weight: 600;
    color: {ACCENT};
    margin-bottom: 14px;
}}

/* ================= TABS ================= */
div[data-baseweb="tab"] {{
    font-size: 0.95rem;
    font-weight: 600;
}}

div[data-baseweb="tab"][aria-selected="true"] {{
    color: {ACCENT};
    border-bottom: 3px solid {ACCENT};
}}

/* ================= BUTTON ================= */
div.stButton > button {{
    background: linear-gradient(90deg, #10b981, #34d399);
    color: white;
    border-radius: 10px;
    padding: 10px 20px;
    font-size: 15px;
    border: none;
    transition: all 0.25s ease-in-out;
}}

div.stButton > button:hover {{
    background: linear-gradient(90deg, #059669, #10b981);
    transform: translateY(-1px);
}}

div.stButton > button:active {{
    transform: scale(0.98);
}}

/* ================= FOOTER ================= */
.app-footer {{
    margin-top: 50px;
    padding: 18px;
    background-color: white;
    border-top: 1px solid {BORDER};
    text-align: center;
    font-size: 0.9rem;
    color: #475569;
}}
</style>
""", unsafe_allow_html=True)

# =====================================================
# HEADER
# =====================================================
st.markdown("""
<div class="app-header">
    <div class="logo-box">🍽️</div>
    <div class="header-text">
        <h1>Restaurant Wait Time Prediction</h1>
        <p>Machine Learning system for efficient restaurant operations</p>
    </div>
</div>
""", unsafe_allow_html=True)

# =====================================================
# MAIN LAYOUT
# =====================================================
left_col, right_col = st.columns([1.3, 1])

# =====================================================
# INPUT CARD (WITH TABS)
# =====================================================
with left_col:
    st.markdown("<div class='card'>", unsafe_allow_html=True)
    st.markdown("<div class='card-title'>Restaurant Inputs</div>", unsafe_allow_html=True)

    input_tabs = st.tabs(["🗓️ Time", "👥 Capacity", "🍳 Food Preparation "])

    with input_tabs[0]:
        day = st.selectbox(
            "Day of Week",
            ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"]
        )
        time_slot = st.selectbox("Time Slot", ["Breakfast","Lunch","Dinner"])
        is_weekend_ui = st.selectbox("Weekend?", ["No", "Yes"])

    with input_tabs[1]:
        customers_waiting = st.slider("Customers Waiting", 0, 80, 30)
        tables_available = st.slider("Tables Available", 0, 30, 10)
        staff_on_duty = st.slider("Staff On Duty", 3, 20, 8)

    with input_tabs[2]:
        avg_prep_time = st.slider("Average Preparation Time (mins)", 5, 40, 20)

    st.markdown("</div>", unsafe_allow_html=True)

# =====================================================
# PREDICTION CARD
# =====================================================
with right_col:
    st.markdown("<div class='card'>", unsafe_allow_html=True)
    st.markdown("<div class='card-title'>Prediction Result</div>", unsafe_allow_html=True)

    is_weekend = 1 if is_weekend_ui == "Yes" else 0

    payload = {
        "day_of_week": day,
        "time_slot": time_slot,
        "customers_waiting": customers_waiting,
        "tables_available": tables_available,
        "staff_on_duty": staff_on_duty,
        "avg_prep_time": avg_prep_time,
        "is_weekend": is_weekend
    }

    if st.button("Predict Waiting Time"):
        with st.spinner("Calculating waiting time..."):
            time.sleep(1)

        try:
            response = requests.post(
                "http://127.0.0.1:5000/predict",
                json=payload
            )

            if response.status_code == 200:
                wait_time = response.json()["predicted_wait_time"]
                st.success(f"Estimated Waiting Time: **{wait_time} minutes**")
            else:
                st.error("Prediction API returned an error")

        except Exception:
            st.error("Backend API is not running")

    st.markdown("</div>", unsafe_allow_html=True)

# =====================================================
# FOOTER
# =====================================================
st.markdown("""
<div class="app-footer">
    © 2026 Smart Restaurant Analytics • Streamlit Web Application • Machine Learning
</div>
""", unsafe_allow_html=True)
