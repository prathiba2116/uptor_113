from flask import Flask, request, jsonify, render_template_string
import joblib
import pandas as pd

model = joblib.load("best_model.pkl")
app = Flask(__name__)

HTML_FORM = """
<h2>Restaurant Wait Time Prediction</h2>
<form method="post">
  Day: <input name="day_of_week"><br><br>
  Time Slot: <input name="time_slot"><br><br>
  Customers Waiting: <input name="customers_waiting" type="number"><br><br>
  Tables Available: <input name="tables_available" type="number"><br><br>
  Staff On Duty: <input name="staff_on_duty" type="number"><br><br>
  Avg Prep Time: <input name="avg_prep_time" type="number"><br><br>
  Is Weekend (0/1): <input name="is_weekend" type="number"><br><br>
  <button type="submit">Predict</button>
</form>
"""

@app.route("/")
def home():
    return "Restaurant Wait Time Prediction API is running"

@app.route("/predict", methods=["GET", "POST"])
def predict():
    if request.method == "GET":
        return render_template_string(HTML_FORM)

    data = {
        "day_of_week": request.form["day_of_week"],
        "time_slot": request.form["time_slot"],
        "customers_waiting": int(request.form["customers_waiting"]),
        "tables_available": int(request.form["tables_available"]),
        "staff_on_duty": int(request.form["staff_on_duty"]),
        "avg_prep_time": int(request.form["avg_prep_time"]),
        "is_weekend": int(request.form["is_weekend"])
    }

    #Examples
    #input values:
    #"day_of_week": Saturday
    #"time_slot": Dinner
    #"customers_waiting": 35
    #"tables_available": 5
    #"staff_on_duty": 6
    #"avg_prep_time": 25



    df = pd.DataFrame([data])

    # -----------------------------
    # FEATURE ENGINEERING (IMPORTANT)
    # -----------------------------
    df["load_per_staff"] = df["customers_waiting"] / (df["staff_on_duty"] + 1)

    df["is_peak_hour"] = df["time_slot"].map({
        "Breakfast": 0,
        "Lunch": 1,
        "Dinner": 1
    })

    pred = model.predict(df)[0]

    return f"<h3>Predicted Wait Time: {pred:.2f} minutes</h3>"

if __name__ == "__main__":
    app.run(debug=True)
